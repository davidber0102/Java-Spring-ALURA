package com.porfile.literalura.Dto;

import java.time.Year;

public record AutorDto(
        String nombreAutor,
        Year anioNacimientoAutor,
        Year anioFallecimientoAutor) {
}
