package com.porfile.literalura.Model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name="libros")
public class Libro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLibro;
    @Column(unique = true)
    private String titulo;
    private String idioma;
    private Integer descargasTotales;
    private String copyright;
    private String topic;
    @OneToMany(mappedBy = "libro", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Autor> autores;

   //Construcores
    public Libro(){ }

    public Libro (DatosLibro datosLibro){
        this.titulo = datosLibro.titulo();
        this.idioma = datosLibro.idioma();
        this.descargasTotales = datosLibro.descargasTotales();
        this.copyright = datosLibro.copyright();
        this.topic = datosLibro.topic();
    }

    public List<Autor> getAutor(){ return autores;}

    public void setAutor(List<Autor> autores){
        autores.forEach(e -> e.setLibro(this));
        this.autores = autores;
    }

   //Getter and Setters
    public Long getIdLibro() {return idLibro;}

    public void setIdLibro(Long idLibro) {this.idLibro = idLibro;}

    public String getTitulo() {return titulo;}

    public void setTitulo(String titulo) {this.titulo = titulo;}

    public String getIdioma() {return idioma;}

    public void setIdioma(String idioma) {this.idioma = idioma;}

    public Integer getDescargasTotales() {return descargasTotales;}

    public void setDescargasTotales(Integer descargasTotales) {
        this.descargasTotales = descargasTotales;}

    public String getCopyright() {return copyright;}

    public void setCopyright(String copyright) {this.copyright = copyright;}

    public String getTopic() {return topic;}

    public void setTopic(String topic) {this.topic = topic;}

    public List<Autor> getAutores() {return autores;}

    public void setAutores(List<Autor> autores) {this.autores = autores;}

    @Override
    public String toString() {
        return "idLibro=" + idLibro +
                ", titulo='" + titulo + '\'' +
                ", idioma='" + idioma + '\'' +
                ", DescargasTotales=" + descargasTotales +
                ", copyright='" + copyright + '\'' +
                ", topic='" + topic + '\'' +
                ", autores=" + autores ;
    }
}

