package com.porfile.literalura.Repositorio;

import com.porfile.literalura.Model.Libro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibroRepository extends JpaRepository<Libro, Long> {
}
