package com.porfile.literalura.Model;

import jakarta.persistence.*;

import java.time.Year;
import java.util.List;

@Entity
@Table(name="autores")
public class Autor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAutor;
    private String nombreAutor;
    private Year anioNacimientoAutor;
    private Year anioFallecimientoAutor;
    @ManyToOne
    private Libro libro;

    public Autor(){ }

    public Autor(String nombreAutor, DatosAutor d){
        this.nombreAutor = d.nombreAutor();
        this.anioNacimientoAutor = d.anioNacimientoAutor();
    }

    public Long getIdAutor() { return idAutor;}

    public void setIdAutor(Long idAutor) {this.idAutor = idAutor;}

    public String getNombreAutor() {return nombreAutor;}

    public void setNombreAutor(String nombreAutor) {this.nombreAutor = nombreAutor;}

    public Year getAnioNacimientoAutor() {return anioNacimientoAutor;}

    public void setAnioNacimientoAutor(Year anioNacimientoAutor) {this.anioNacimientoAutor = anioNacimientoAutor;}

    public Year getAnioFallecimientoAutor() {return anioFallecimientoAutor;}

    public void setAnioFallecimientoAutor(Year anioFallecimientoAutor) {this.anioFallecimientoAutor = anioFallecimientoAutor;}

    public Libro getLibro() {return libro;}

    public void setLibro(Libro libro) {this.libro = libro;}

    @Override
    public String toString() {
        return "Autor{" +
                "idAutor=" + idAutor +
                ", nombreAutor='" + nombreAutor + '\'' +
                ", anioNacimientoAutor=" + anioNacimientoAutor +
                ", anioFallecimientoAutor=" + anioFallecimientoAutor +
                ", libro=" + libro +
                '}';
    }
}
