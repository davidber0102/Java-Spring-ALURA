package com.porfile.literalura.Dto;

public record LibroDto(
        Long idLibro,
        String titulo,
        String idioma,
        Integer descargasTotales,
        String copyright,
         String topic) {
}
