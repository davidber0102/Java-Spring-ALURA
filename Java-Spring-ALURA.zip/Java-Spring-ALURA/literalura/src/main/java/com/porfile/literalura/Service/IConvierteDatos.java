package com.porfile.literalura.Service;

public interface IConvierteDatos {
    <T> T datosAPI(String json, Class<T> clase);
}
