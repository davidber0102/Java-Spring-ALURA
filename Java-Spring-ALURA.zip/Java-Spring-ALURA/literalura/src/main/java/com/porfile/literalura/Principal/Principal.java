package com.porfile.literalura.Principal;

import com.porfile.literalura.Model.DatosLibro;
import com.porfile.literalura.Model.Libro;
import com.porfile.literalura.Repositorio.LibroRepository;
import com.porfile.literalura.Service.ApiGutendex;
import com.porfile.literalura.Service.ConvierteDatos;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Principal {
    private Scanner teclado = new Scanner(System.in);
    private ApiGutendex consumoApi = new ApiGutendex();
    private final String URL_BASE = "https://gutendex.com/books?";
   private ConvierteDatos conversor = new ConvierteDatos();
    private List<DatosLibro> datosSerie = new ArrayList<>();
    private List<Libro> series;
    private Optional<Libro> serieBuscada;
    private final LibroRepository repositorio;

    public Principal(LibroRepository repository) {this.repositorio = repository;}

    public void muestraElMenu() {
        boolean correr = true;
        while (correr) {
            mensajeBienvenida();
            Menu();
            var opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
               case 1 -> buscarLibroPorTitulo();
                //case 2 -> listarLibrosRegistrados();
                //case 3 -> listarAutoresRegistrados();
                //case 4 -> listarAutoresVivos();
                //case 5 -> listarAutoresVivosRefinado();
                //case 6 -> listarAutoresPorAnoDeMorte();
                //case 7 -> listarLibrosPorIdioma();
                case 0 -> {
                    System.out.println("Encerrando a LiterAlura!");
                    correr = false;
                }
                default -> System.out.println("Opcion inválida!");
            }
        }
    }


    private void Menu() {
        System.out.println("""
            ===========================================================
            ===========================================================
            ----------------   CHALLENGER LITERALURA   -----------------------
                   Aplicacion generada en base de esferzos !
                   Puede elegir cualquier opcion del siguiente Menuo:
            -----------------------------------------------------------
                                 Menu
                       1- Buscar libro por titulo
                       2- Listar libros registrados
                       3- Listar autores registrados
                       4- Listar autores vivos en un año determinado
                       5- Listar autores nacidos en un año determindo
                       6- Listar autores por año de sue Fallecimiento
                       7- Listar libros en un determinado Idioma
                       0- Sair
                        -----------------------------------------------------------
            ===========================================================
            ===========================================================
            """);
    }

    private void mensajeBienvenida(){
        System.out.println("""
            ===========================================================
            ===========================================================
            -----------Bienvenido al Challenger Liter-Alura-----------
            -------------------------------------------------------------
            --------Codifigicado por: Bernal Diaz David---------------
            -----------------------------------------------------------
            ---------------Curso Back-Emd ALURA-ORACLE----------------- 
                """);
    }

    private DatosSerie getDatosSerie() {
        System.out.println("Escribe el titulo del Libro que deseas buscar: ");
        var nombreLibro = teclado.nextLine();
        var json = consumoApi.datosAPI(URL_BASE + nombreLibro.replace(" ", "%20"));
        System.out.println(json);
        DatosSerie datos = conversor.obtenerDatos(json, DatosSerie.class);
        return datos;
    }
    private void buscarLibroPorTitulo() {
        DatosSerie datos = getDatosSerie();
        //datosSerie.add(datos);
        Serie serie = new Serie(datos);
        repositorio.save(serie);
        System.out.println(datos);


        System.out.println("Ingrese el título del libro:");
        String title = scanner.nextLine();
        DatosSerie datos = getDatosSerie();
        //datosSerie.add(datos);
        Serie serie = new Serie(datos);
        repositorio.save(serie);
        System.out.println(datos);
    }

    }
