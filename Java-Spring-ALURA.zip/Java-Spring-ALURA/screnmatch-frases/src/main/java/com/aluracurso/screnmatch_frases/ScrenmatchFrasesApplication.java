package com.aluracurso.screnmatch_frases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScrenmatchFrasesApplication {

	public static void main(String[] args) {

		SpringApplication.run(ScrenmatchFrasesApplication.class, args);
	}

}
