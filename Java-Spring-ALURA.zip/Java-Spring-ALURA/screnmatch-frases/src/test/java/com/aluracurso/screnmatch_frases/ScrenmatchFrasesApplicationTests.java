package com.aluracurso.screnmatch_frases;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrenmatchFrasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
