package br.com.alura.screensound.model;

public enum TipoArtista {
    SOLO,
    DUO,
    BANDA;
}
