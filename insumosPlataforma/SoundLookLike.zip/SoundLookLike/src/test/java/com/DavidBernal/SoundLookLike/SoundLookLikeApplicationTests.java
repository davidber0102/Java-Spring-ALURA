package com.DavidBernal.SoundLookLike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoundLookLikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
