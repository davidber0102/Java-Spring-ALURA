package com.DavidBernal.SoundLookLike;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoundLookLikeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoundLookLikeApplication.class, args);
	}

}
